create function update_storage_on_buy() returns trigger
    language plpgsql
as
$$
BEGIN

    IF (SELECT quantity FROM products WHERE id_product = NEW.product_id) < NEW.quantity THEN
        RAISE EXCEPTION 'Недостаточно товара на складе. ID товара: %, Название: %',
            NEW.product_id,
            (SELECT product_name FROM products WHERE id_product = NEW.product_id);
    END IF;

    UPDATE products
    SET quantity = products.quantity - NEW.quantity
    WHERE id_product = NEW.product_id;

    RETURN NEW;
END;
$$;

alter function update_storage_on_buy() owner to postgres;

