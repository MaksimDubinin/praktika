create function update_storage_on_supply() returns trigger
    language plpgsql
as
$$
BEGIN

    UPDATE products
    SET quantity = products.quantity + NEW.quantity
    WHERE id_product = NEW.id_product;

    RETURN NEW;
END;
$$;

alter function update_storage_on_supply() owner to postgres;

