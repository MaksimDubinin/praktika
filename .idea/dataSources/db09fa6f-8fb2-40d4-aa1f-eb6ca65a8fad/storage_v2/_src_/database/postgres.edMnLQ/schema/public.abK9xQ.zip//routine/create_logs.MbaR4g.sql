create function create_logs() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO logs(username, operation_type, tablename)
    VALUES (current_user, TG_OP, TG_TABLE_NAME);

    RETURN NEW;
END;
$$;

alter function create_logs() owner to postgres;

