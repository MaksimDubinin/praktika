create function update_supplier_sales() returns trigger
    language plpgsql
as
$$
DECLARE
    current_supplier_id INT;
    current_supplier_name varchar(255);
BEGIN

    SELECT supplierId INTO current_supplier_id
    FROM products
    WHERE id_product = NEW.product_id;

    SELECT supplier_name INTO current_supplier_name
    FROM suppliers
    WHERE id_supplier = current_supplier_id;

    IF EXISTS (SELECT 1 FROM suppliers WHERE id_supplier = current_supplier_id) THEN
        UPDATE suppliers
        SET total_sells = suppliers.total_sells + NEW.quantity
        WHERE id_supplier = current_supplier_id;
    ELSE
        RAISE notice 'Такого поставщика нету!!!';
    END IF;

    RETURN NEW;
END;
$$;

alter function update_supplier_sales() owner to postgres;

